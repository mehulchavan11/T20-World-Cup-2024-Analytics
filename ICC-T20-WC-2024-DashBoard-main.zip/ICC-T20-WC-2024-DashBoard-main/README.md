# **ICC Men’s T20 World Cup 2024 – End-to-End Analytics Project**

### **Overview**
This project presents a **complete analytics workflow** for the ICC Men’s T20 World Cup 2024 – from **data collection** to **interactive visualization**. The goal is to uncover **actionable insights** into team performance, player impact, and tournament trends using a structured analytics pipeline.

---

### **Project Workflow**
1. **Data Scraping** – Python scripts (Playwright, BeautifulSoup) to collect match and player statistics.
2. **Data Preparation** – Clean and structure the raw data into analysis-ready CSV files.
3. **Dashboard Development** – Build an interactive Power BI dashboard for visual analytics.
4. **Insight Delivery** – Generate reports on performance, trends, and Best XI selection.

---

### **Dashboard Sections**

#### **1. Tournament Overview**
- Match results, points table, and stage-wise progression.
- Key tournament metrics (total runs, wickets, sixes, etc.).

#### **2. Team Performance**
- Win-loss records, Net Run Rate (NRR) analysis.
- Consistency across phases (powerplay, middle, death overs).

#### **3. Batting Analysis**
- Runs scored, strike rates, boundary percentages.
- Player impact score (combining volume and efficiency).

#### **4. Bowling Analysis**
- Wickets taken, economy rates, dot-ball percentages.
- Performance in pressure situations (death overs, high-scoring matches).

#### **5. Best XI & Player Comparison**
- Data-driven selection of tournament Best XI.
- Player comparisons using custom performance indices.

---

### **Repository Structure**
```
T20-World-Cup-2024-Analytics/
│
├── scraping/           # Python web scraping scripts
│   ├── batter_data_scraper.py
│   └── bowler_data_scraper.py
│
├── data/               # Cleaned datasets (CSV format)
│   ├── matches.csv
│   ├── batting_stats.csv
│   └── bowling_stats.csv
│
├── dashboard/          # Power BI files
│   └── T20WC_2024_Analytics.pbix
│
├── screenshots/        # Dashboard preview images
│   ├── overview.png
│   └── batting_analysis.png
│
└── README.md
```

---

### **Technology Stack**
- **Python** – Data scraping and cleaning (Playwright, BeautifulSoup, Pandas)
- **Power BI** – Data modeling, DAX, and interactive visualization
- **GitHub** – Version control and project documentation

---

### **How to Use This Project**

#### **Option 1: Use Pre-Built Dashboard**
1. Download the `dashboard/T20WC_2024_Analytics.pbix` file
2. Open with **Power BI Desktop**
3. Explore using filters and slicers

#### **Option 2: Recreate from Scratch**
1. Run scraping scripts:
   ```bash
   python scraping/match_data_scraper.py
   python scraping/player_stats_scraper.py
   ```
2. Clean and validate data in `data/` folder
3. Import data into Power BI and rebuild visuals

---

### **Key Analytical Features**
- **Smart Filtering** – Minimum innings/overs thresholds to exclude part-time players
- **Combined Metrics** – Scatter plots showing efficiency vs. volume (e.g., SR vs. Runs)
- **Context-Aware Aggregation** – Weighted averages to handle small sample sizes
- **Impact Scoring** – Custom formulas to evaluate player contributions
- **Comparative Analysis** – Head-to-head player and team comparisons

---

### **Project Outcomes**
- Identified top performers across batting and bowling disciplines
- Revealed team strengths/weaknesses in different match phases
- Created a balanced, data-driven "Tournament Best XI"
- Provided interactive tools for ongoing match analysis

---

### **Disclaimer**
This is an **educational project** for data analytics demonstration.  
All data is sourced from publicly available cricket statistics websites.  
Not affiliated with ICC or any official cricket organization.

---

### **Author**
**Pratik Chinchawadkar**  
Computer Science Student | Data & Analytics Enthusiast  

---

