import requests
from bs4 import BeautifulSoup
import pandas as pd

# Test with first match
TEST_URL = "https://www.espncricinfo.com/series/icc-men-s-t20-world-cup-2024-1411166/afghanistan-vs-australia-48th-match-super-eights-group-1-1415748/full-scorecard"

HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)",
    "Accept-Language": "en-US,en;q=0.9",
}


def get_soup(url):
    r = requests.get(url, headers=HEADERS, timeout=30)
    r.raise_for_status()
    return BeautifulSoup(r.content, "html.parser")


print("🔍 DIAGNOSTIC: Analyzing ESPN bowling table structure...")
print("=" * 70)
print(f"Testing URL: {TEST_URL}\n")

soup = get_soup(TEST_URL)

# Find all tables
all_tables = soup.find_all("table")
print(f"📊 Total tables found: {len(all_tables)}\n")

for idx, table in enumerate(all_tables, 1):
    print(f"\n{'=' * 70}")
    print(f"TABLE {idx}")
    print('=' * 70)

    # Get headers
    headers = table.find_all('th')
    if headers:
        header_texts = [th.get_text(strip=True) for th in headers]
        print(f"Headers: {header_texts}")

    # Get first 3 rows
    tbody = table.find('tbody') or table
    rows = tbody.find_all('tr')[:3]

    print(f"Total rows in table: {len(tbody.find_all('tr'))}")
    print(f"\nFirst 3 rows:")

    for row_idx, tr in enumerate(rows, 1):
        tds = tr.find_all('td')
        if tds:
            print(f"\n  Row {row_idx} ({len(tds)} columns):")
            for col_idx, td in enumerate(tds):
                text = td.get_text(strip=True)
                # Show first 50 chars
                text = text[:50] + "..." if len(text) > 50 else text
                print(f"    Col {col_idx}: '{text}'")

    # Try to determine if this is batting or bowling
    print(f"\n  Table Type Analysis:")

    # Check for batting indicators
    batting_keywords = ['batter', 'batting', 'r', 'b', '4s', '6s', 'sr']
    bowling_keywords = ['bowler', 'bowling', 'o', 'm', 'w', 'econ']

    header_lower = ' '.join(header_texts).lower()

    batting_score = sum(1 for kw in batting_keywords if kw in header_lower)
    bowling_score = sum(1 for kw in bowling_keywords if kw in header_lower)

    print(f"    Batting keywords found: {batting_score}")
    print(f"    Bowling keywords found: {bowling_score}")

    if bowling_score > batting_score:
        print(f"    → Likely BOWLING table")

        # Show actual data values from first data row
        first_data_row = tbody.find_all('tr')[0] if tbody.find_all('tr') else None
        if first_data_row:
            tds = first_data_row.find_all('td')
            if len(tds) >= 6:
                print(f"\n    First bowler analysis:")
                print(f"      Name (col 0): '{tds[0].get_text(strip=True)}'")
                print(f"      Col 1: '{tds[1].get_text(strip=True)}'")
                print(f"      Col 2: '{tds[2].get_text(strip=True)}'")
                print(f"      Col 3: '{tds[3].get_text(strip=True)}'")
                print(f"      Col 4: '{tds[4].get_text(strip=True)}'")
                print(f"      Col 5: '{tds[5].get_text(strip=True)}'")

                # Try to validate as bowling
                try:
                    col1_val = tds[1].get_text(strip=True)
                    print(f"\n    Validation check:")
                    print(f"      Col 1 value: '{col1_val}'")
                    print(f"      Has decimal? {'.' in col1_val}")

                    if '.' in col1_val:
                        overs = float(col1_val)
                        print(f"      Parsed as overs: {overs}")
                        print(f"      In range 0-20? {0 <= overs <= 20}")
                except Exception as e:
                    print(f"      Parse error: {e}")

    elif batting_score > bowling_score:
        print(f"    → Likely BATTING table")
    else:
        print(f"    → Unknown table type")

print("\n" + "=" * 70)
print("✅ Diagnostic complete!")
print("\nNext step: Run this script and share the output so I can fix the scraper.")