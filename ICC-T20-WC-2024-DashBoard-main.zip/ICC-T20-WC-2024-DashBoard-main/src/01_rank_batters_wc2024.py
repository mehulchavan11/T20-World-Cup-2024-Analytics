import pandas as pd
from sklearn.preprocessing import MinMaxScaler
import os

INPUT = "data/processed/wc_2024_batting.csv"
OUTPUT = "data/analytics/ranked_batters_wc2024.csv"

os.makedirs("data/analytics", exist_ok=True)

# Load
bat = pd.read_csv(INPUT)

# Clean numeric columns
num_cols = ["runs", "balls", "strike_rate"]
for c in num_cols:
    bat[c] = pd.to_numeric(bat[c], errors="coerce")

bat = bat.dropna(subset=["runs", "balls", "strike_rate"])

# Aggregate per player
bat_agg = (
    bat.groupby(["player", "team"], as_index=False)
    .agg(
        matches=("match_no", "nunique"),
        runs=("runs", "sum"),
        balls=("balls", "sum"),
        strike_rate=("strike_rate", "mean")
    )
)

# Approx batting position
def batting_position(balls):
    if balls >= 25:
        return "Top Order"
    elif balls >= 12:
        return "Middle Order"
    else:
        return "Lower Order"

bat_agg["batting_role"] = bat_agg["balls"].apply(batting_position)

# Normalize
scaler = MinMaxScaler()
bat_agg[["norm_runs", "norm_sr"]] = scaler.fit_transform(
    bat_agg[["runs", "strike_rate"]]
)

# Batting score
bat_agg["bat_score"] = (
    0.6 * bat_agg["norm_runs"] +
    0.4 * bat_agg["norm_sr"]
)

# Rank
bat_agg = bat_agg.sort_values("bat_score", ascending=False)
bat_agg["rank"] = range(1, len(bat_agg) + 1)

# Save
bat_agg.to_csv(OUTPUT, index=False)
print("✅ Ranked batters saved:", OUTPUT)
