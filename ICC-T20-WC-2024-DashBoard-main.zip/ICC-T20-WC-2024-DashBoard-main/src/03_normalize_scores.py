import pandas as pd
import os
import re

INPUT_FILE = "data/processed/wc_2024_match_summary.csv"
OUTPUT_FILE = "data/processed/wc_2024_match_summary_clean.csv"


def split_score(score):
    """
    Converts score string like:
    '176/7' -> (176, 7)
    '149'   -> (149, 10)
    None    -> (None, None)
    """
    if pd.isna(score):
        return None, None

    score = str(score).strip()

    # Match runs/wickets
    match = re.match(r"(\d+)(?:/(\d+))?", score)
    if not match:
        return None, None

    runs = int(match.group(1))
    wickets = int(match.group(2)) if match.group(2) else 10

    return runs, wickets


if __name__ == "__main__":
    print("Loading match summary...")
    df = pd.read_csv(INPUT_FILE)

    print("Normalizing scores...")

    df[["runs1", "wickets1"]] = df["score1"].apply(
        lambda x: pd.Series(split_score(x))
    )

    df[["runs2", "wickets2"]] = df["score2"].apply(
        lambda x: pd.Series(split_score(x))
    )

    os.makedirs("data/processed", exist_ok=True)

    df.to_csv(OUTPUT_FILE, index=False)

    print("✅ Score normalization complete")
    print(f"Saved cleaned file to: {OUTPUT_FILE}")