import requests
from bs4 import BeautifulSoup
import pandas as pd
import os

URL = "https://www.espncricinfo.com/series/icc-men-s-t20-world-cup-2024-1411166/match-schedule-fixtures-and-results"

HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)",
    "Accept-Language": "en-US,en;q=0.9",
    "Referer": "https://www.espncricinfo.com/"
}

SERIES_KEY = "icc-men-s-t20-world-cup-2024-1411166"

KEYWORDS = ["match", "semi-final", "final"]

def get_match_links(url):
    response = requests.get(url, headers=HEADERS, timeout=30)
    response.raise_for_status()

    soup = BeautifulSoup(response.content, "html.parser")

    links = set()

    for a in soup.find_all("a", href=True):
        href = a["href"]

        if (
            SERIES_KEY in href
            and "live-cricket-score" in href
            and any(k in href for k in KEYWORDS)
        ):
            full_url = (
                "https://www.espncricinfo.com"
                + href.replace("live-cricket-score", "full-scorecard")
            )
            links.add(full_url)

    return sorted(links)


if __name__ == "__main__":
    print("Scraping ICC T20 WC 2024 match links (final+semi safe)...")

    match_links = get_match_links(URL)

    print(f"Total WC 2024 matches found: {len(match_links)}")

    os.makedirs("data/raw", exist_ok=True)

    pd.DataFrame({"match_url": match_links}).to_csv(
        "data/raw/wc_2024_match_links.csv", index=False
    )

    print("✅ WC 2024 links saved correctly")