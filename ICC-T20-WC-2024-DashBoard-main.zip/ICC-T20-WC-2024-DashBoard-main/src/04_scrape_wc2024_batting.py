import asyncio
from playwright.async_api import async_playwright
from bs4 import BeautifulSoup
import pandas as pd
import re
import os
import traceback
from utils import normalize_team

# =============================
# CONFIG
# =============================
LINKS_FILE = "data/raw/wc_2024_match_links.csv"
OUTPUT_FILE = "data/processed/wc_2024_batting.csv"


# =============================
# HELPERS
# =============================

def extract_match_no(url):
    """Identifies the match number (1-55) from the URL."""
    url = url.lower()
    m = re.search(r"-(\d+)(?:st|nd|rd|th)-match", url)
    if m:
        return int(m.group(1))

    # Handle Knockouts
    if "final" in url and "semi" not in url: return 55
    if "semi-final-1" in url or "1st-semi" in url: return 53
    if "semi-final-2" in url or "2nd-semi" in url: return 54
    return 0


def get_innings_teams(soup):
    """
    Scans the entire page for headers like 'Canada Innings', 'USA Innings'.
    Returns a list of teams in the order they batted.
    """
    teams = []
    # Search for any text containing "Innings"
    # This captures the section titles above the tables
    candidates = soup.find_all(string=re.compile(r"Innings", re.IGNORECASE))

    for c in candidates:
        text = c.strip()
        # Filter out noise (e.g. "Match Innings", long sentences)
        if "Innings" in text and len(text) < 40 and "Match" not in text:
            # Clean: "Canada Innings" -> "Canada"
            raw_team = text.replace("Innings", "").strip()
            # Normalize using your utils function
            normalized = normalize_team(raw_team)

            # Add to list if valid and not a duplicate
            if normalized and normalized not in teams:
                teams.append(normalized)

    return teams


def parse_batting_table(table, team, match_no):
    """
    Parses a batting table using DYNAMIC column mapping.
    Fixes the 'Minutes' column shift issue.
    """
    rows = []

    # 1. Map Columns by Header Text
    headers = [th.get_text(strip=True).lower() for th in table.find_all("th")]
    col_map = {}

    for i, h in enumerate(headers):
        if h == 'r':
            col_map['runs'] = i
        elif h == 'b':
            col_map['balls'] = i
        elif h == '4s':
            col_map['fours'] = i
        elif h == '6s':
            col_map['sixes'] = i
        elif h == 'sr':
            col_map['sr'] = i

    # Validate table
    if 'runs' not in col_map or 'balls' not in col_map:
        return []

    # 2. Extract Rows
    tbody = table.find('tbody') or table
    for tr in tbody.find_all("tr"):
        tds = tr.find_all("td")

        # Skip rows that are too short
        if not tds or len(tds) <= max(col_map.values()):
            continue

        # Player Name
        player_cell = tds[0]
        player_text = player_cell.get_text(strip=True)
        player_text = player_text.replace('†', '').replace('(c)', '').replace('(wk)', '')
        player_text = re.sub(r'\s+', ' ', player_text).strip()

        # Stop at summary rows
        if any(x in player_text.lower() for x in ['extras', 'total', 'did not bat', 'fall of wickets']):
            break
        if not player_text: continue

        # Out Status
        out_status = "not out"
        if len(tds) > 1:
            out_status = tds[1].get_text(strip=True) or "not out"

        try:
            # Extract numbers dynamically
            runs = int(tds[col_map['runs']].get_text(strip=True) or 0)
            balls = int(tds[col_map['balls']].get_text(strip=True) or 0)

            fours = 0
            if 'fours' in col_map:
                fours = int(tds[col_map['fours']].get_text(strip=True) or 0)

            sixes = 0
            if 'sixes' in col_map:
                sixes = int(tds[col_map['sixes']].get_text(strip=True) or 0)

            sr = 0.0
            if 'sr' in col_map:
                sr_text = tds[col_map['sr']].get_text(strip=True)
                if sr_text and sr_text != '-':
                    sr = float(sr_text)

            rows.append({
                "match_no": match_no,
                "team": team,
                "player": player_text,
                "runs": runs,
                "balls": balls,
                "fours": fours,
                "sixes": sixes,
                "strike_rate": sr,
                "out_status": out_status
            })
        except ValueError:
            continue

    return rows


# =============================
# ASYNC MAIN (PLAYWRIGHT)
# =============================

async def main():
    if not os.path.exists(LINKS_FILE):
        print(f"❌ Error: {LINKS_FILE} not found.")
        return

    links_df = pd.read_csv(LINKS_FILE)
    all_batting_data = []

    print(f"🏏 Starting Batting Extraction (Playwright) for {len(links_df)} matches...")

    async with async_playwright() as p:
        # Launch visible browser
        browser = await p.chromium.launch(headless=False)
        page = await browser.new_page()

        for i, url in enumerate(links_df["match_url"]):
            try:
                # Fix URL
                scorecard_url = url.replace("live-cricket-score",
                                            "full-scorecard") if "full-scorecard" not in url else url

                # Navigate
                await page.goto(scorecard_url, timeout=60000)

                # Wait for table
                try:
                    await page.wait_for_selector("table", timeout=5000)
                except:
                    print(f"⚠️ Timeout waiting for table on {scorecard_url}")

                # Get HTML
                content = await page.content()
                soup = BeautifulSoup(content, "html.parser")

                match_no = extract_match_no(scorecard_url)

                # 1. Identify Teams using Global Search (Fixes "Unknown Team")
                innings_teams = get_innings_teams(soup)

                # 2. Identify Batting Tables
                batting_tables = []
                for tbl in soup.find_all("table"):
                    headers = [th.get_text(strip=True).lower() for th in tbl.find_all("th")]
                    if 'r' in headers and 'b' in headers and 'sr' in headers:
                        batting_tables.append(tbl)

                # 3. Match Tables to Teams
                # We expect the order of tables to match the order of "Innings" headers
                extracted_count = 0
                for idx, table in enumerate(batting_tables[:2]):

                    # Fallback if we couldn't find a header for this innings
                    if idx < len(innings_teams):
                        team_name = innings_teams[idx]
                    else:
                        team_name = "Unknown Team"

                    rows = parse_batting_table(table, team_name, match_no)
                    all_batting_data.extend(rows)
                    extracted_count += len(rows)

                print(f"✅ Match {match_no}: {extracted_count} records. Teams: {innings_teams}")

                await asyncio.sleep(1)

            except Exception as e:
                print(f"❌ Error on {url}: {e}")
                traceback.print_exc()

        await browser.close()

    # SAVE
    if all_batting_data:
        df = pd.DataFrame(all_batting_data)

        # Deduplicate
        df = df.drop_duplicates(subset=['match_no', 'team', 'player', 'runs'], keep='first')

        # Sort
        df = df.sort_values(by=['match_no', 'team', 'runs'], ascending=[True, True, False])

        os.makedirs("data/processed", exist_ok=True)
        df.to_csv(OUTPUT_FILE, index=False)
        print(f"\n🎉 SUCCESS! Saved {len(df)} batting rows to {OUTPUT_FILE}")
        print("\n🔍 Sample Data:")
        print(df[['player', 'team', 'runs', 'fours']].head(5))
    else:
        print("\n❌ No data extracted.")


if __name__ == "__main__":
    asyncio.run(main())