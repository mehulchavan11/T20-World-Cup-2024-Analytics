import asyncio
from playwright.async_api import async_playwright
from bs4 import BeautifulSoup
import pandas as pd
import os
import re

# --- CONFIG ---
# The specific match we are missing: India vs England (Semi-Final 2)
MISSING_MATCH_URL = "https://www.espncricinfo.com/series/icc-men-s-t20-world-cup-2024-1411166/india-vs-england-2nd-semi-final-1415754/full-scorecard"
OUTPUT_FILE = "data/processed/wc_2024_bowlers_final.csv"


# --- HELPER FUNCTIONS (Copy-pasted so no imports needed) ---
def normalize_team(team_name):
    """Simple normalizer for main teams."""
    if not team_name: return ""
    team_name = team_name.strip()
    replacements = {
        "South": "South Africa", "SA": "South Africa",
        "West": "West Indies", "WI": "West Indies",
        "United": "United States of America", "USA": "United States of America",
        "Sri": "Sri Lanka", "New": "New Zealand", "ENG": "England", "IND": "India"
    }
    return replacements.get(team_name, team_name)


def get_real_match_no(url):
    """Hardcode match 54 for this specific script"""
    return 54


def parse_bowling_table(table, match_no, bowling_team, batting_team):
    data = []
    rows = table.find_all("tr")
    if not rows: return []

    for tr in rows:
        tds = tr.find_all("td")
        if len(tds) < 6: continue

        name = tds[0].get_text(strip=True).replace("†", "").replace("(c)", "").strip()
        if not name or any(x in name.lower() for x in ["extras", "total", "did not bat"]):
            continue

        try:
            data.append({
                "match_no": match_no,
                "bowler": name,
                "team": bowling_team,
                "against": batting_team,
                "overs": float(tds[1].get_text(strip=True)),
                "maidens": int(tds[2].get_text(strip=True)),
                "runs": int(tds[3].get_text(strip=True)),
                "wickets": int(tds[4].get_text(strip=True)),
                "economy": float(tds[5].get_text(strip=True)),
            })
        except:
            continue
    return data


async def main():
    print(f"🚀 Launching browser to fetch Missing Match 54...")

    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=False)
        page = await browser.new_page()

        try:
            # 1. Go to the URL
            await page.goto(MISSING_MATCH_URL, timeout=60000)

            # 2. Wait for table
            try:
                await page.wait_for_selector("table", timeout=10000)
            except:
                print("⚠️ Timeout waiting for table selector.")

            # 3. Parse Content
            content = await page.content()
            soup = BeautifulSoup(content, "html.parser")

            # 4. Define Teams manually for this specific match to avoid errors
            # 2nd Semi-Final: India (Bat 1) vs England (Bat 2)
            teams = ["India", "England"]
            match_no = 54

            # 5. Extract Bowling Tables
            tables = []
            for tbl in soup.find_all("table"):
                headers = [th.get_text(strip=True).upper() for th in tbl.find_all("th")]
                if "O" in headers and "W" in headers and "ECON" in headers:
                    tables.append(tbl)

            print(f"   Found {len(tables)} bowling tables.")

            new_data = []
            # Logic: Table 0 = Innings 1 (Eng Bowling vs Ind Batting)
            #        Table 1 = Innings 2 (Ind Bowling vs Eng Batting)

            # Innings 1 Bowling (England Bowling)
            if len(tables) > 0:
                rows = parse_bowling_table(tables[0], match_no, "England", "India")
                new_data.extend(rows)

            # Innings 2 Bowling (India Bowling)
            if len(tables) > 1:
                rows = parse_bowling_table(tables[1], match_no, "India", "England")
                new_data.extend(rows)

            print(f"✅ Extracted {len(new_data)} rows for Match 54.")

            # 6. Append to CSV
            if new_data and os.path.exists(OUTPUT_FILE):
                df_new = pd.DataFrame(new_data)

                # Load existing to ensure column order matches
                df_existing = pd.read_csv(OUTPUT_FILE)

                # Check if Match 54 already exists to avoid duplicates
                if 54 in df_existing['match_no'].values:
                    print("⚠️ Match 54 already exists in file. Skipping append.")
                else:
                    # Append
                    df_new.to_csv(OUTPUT_FILE, mode='a', header=False, index=False)
                    print(f"🎉 Successfully appended Match 54 to {OUTPUT_FILE}")

        except Exception as e:
            print(f"❌ Error: {e}")

        await browser.close()


if __name__ == "__main__":
    asyncio.run(main())