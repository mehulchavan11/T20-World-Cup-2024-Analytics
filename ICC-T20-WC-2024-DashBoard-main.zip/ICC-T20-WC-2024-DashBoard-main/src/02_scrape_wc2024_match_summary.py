import requests
from bs4 import BeautifulSoup
import pandas as pd
import os
import time
import re
from utils import normalize_team


HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)",
    "Accept-Language": "en-US,en;q=0.9",
}

def get_soup(url):
    r = requests.get(url, headers=HEADERS, timeout=30)
    r.raise_for_status()
    return BeautifulSoup(r.content, "html.parser")


def extract_match_no(url):
    m = re.search(r"-(\d+)(st|nd|rd|th)-match", url)
    return int(m.group(1)) if m else None


def extract_stage(url):
    url = url.lower()
    if "final" in url and "semi" not in url:
        return "Final"
    if "semi-final" in url:
        return "Semi-final"
    if "super-eights" in url:
        return "Super 8"
    if "group-" in url:
        return "Group"
    return "Unknown"


def get_teams(soup):
    teams = []
    for span in soup.find_all("span", class_="ds-text-tight-l"):
        t = span.get_text(strip=True)
        if t and t not in teams:
            teams.append(t)

    return teams[:2]


def get_toss(soup):
    for span in soup.find_all("span"):
        txt = span.get_text(strip=True).lower()
        if "elected to" in txt:
            return span.get_text(strip=True)
    return None


def get_result(soup):
    # Most reliable selector for WC 2024
    for span in soup.find_all("span"):
        text = span.get_text(strip=True).lower()

        if any(k in text for k in [
            "won by",
            "no result",
            "abandoned",
            "tied",
            "match tied",
            "draw"
        ]):
            return span.get_text(strip=True)

    return "Result not available"



def get_scores(soup):
    scores = []
    for div in soup.find_all("div", class_="ds-text-compact-m"):
        for s in div.find_all("strong"):
            scores.append(s.get_text(strip=True))
    return scores[:2]


if __name__ == "__main__":
    df_links = pd.read_csv("data/raw/wc_2024_match_links.csv")

    rows = []

    print(f"Scraping {len(df_links)} WC 2024 matches...")

    for i, url in enumerate(df_links["match_url"], start=1):
        try:
            print(f"[{i}] {url}")
            soup = get_soup(url)

            rows.append({
                "match_no": extract_match_no(url),
                "stage": extract_stage(url),

                "team1": normalize_team((get_teams(soup) + [None, None])[0]),
                "team2": normalize_team((get_teams(soup) + [None, None])[1]),

                "toss": normalize_team(get_toss(soup)),
                "result": normalize_team(get_result(soup)),

                "score1": (get_scores(soup) + [None, None])[0],
                "score2": (get_scores(soup) + [None, None])[1],

                "match_url": url
            })

            time.sleep(1.2)

        except Exception as e:
            print("❌ Error:", e)

    df = pd.DataFrame(rows)

    df = df.sort_values("match_no")

    os.makedirs("data/processed", exist_ok=True)
    df.to_csv("data/processed/wc_2024_match_summary.csv", index=False)

    print("✅ CLEAN & SORTED WC 2024 match summary created")