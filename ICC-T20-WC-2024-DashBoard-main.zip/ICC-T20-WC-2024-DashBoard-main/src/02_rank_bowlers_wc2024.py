import pandas as pd
from sklearn.preprocessing import MinMaxScaler
import os

INPUT = "data/processed/wc_2024_bowlers_final.csv"
OUTPUT = "data/analytics/ranked_bowlers_wc2024.csv"


os.makedirs("data/analytics", exist_ok=True)

# Load
bowl = pd.read_csv(INPUT)
bowl = bowl.rename(columns={"bowler": "player"})


# Clean
num_cols = ["wickets", "economy"]
for c in num_cols:
    bowl[c] = pd.to_numeric(bowl[c], errors="coerce")

bowl = bowl.dropna(subset=["wickets", "economy"])

# Aggregate per player
bowl_agg = (
    bowl.groupby(["player", "team"], as_index=False)
    .agg(
        matches=("match_no", "nunique"),
        wickets=("wickets", "sum"),
        economy=("economy", "mean")
    )
)

# Normalize
scaler = MinMaxScaler()
bowl_agg[["norm_wkts", "norm_econ"]] = scaler.fit_transform(
    bowl_agg[["wickets", "economy"]]
)

# Bowl score (lower economy is better)
bowl_agg["bowl_score"] = (
    0.7 * bowl_agg["norm_wkts"] +
    0.3 * (1 - bowl_agg["norm_econ"])
)

# Rank
bowl_agg = bowl_agg.sort_values("bowl_score", ascending=False)
bowl_agg["rank"] = range(1, len(bowl_agg) + 1)

# Save
bowl_agg.to_csv(OUTPUT, index=False)
print("✅ Ranked bowlers saved:", OUTPUT)
