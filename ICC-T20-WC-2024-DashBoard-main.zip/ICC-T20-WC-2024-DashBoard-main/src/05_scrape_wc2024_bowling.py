import asyncio
from playwright.async_api import async_playwright
from bs4 import BeautifulSoup
import pandas as pd
import os
import re
import traceback
from utils import normalize_team

# --- CONFIG ---
LINKS_FILE = "data/raw/wc_2024_match_links.csv"
OUTPUT_FILE = "data/processed/wc_2024_bowlers_final.csv"


# --- REUSED PARSING LOGIC ---
def get_real_match_no(url, soup):
    """Identify the Match Number (1-55)."""
    url = url.lower()
    m = re.search(r"-(\d+)(?:st|nd|rd|th)-match", url)
    if m: return int(m.group(1))

    if "final" in url and "semi" not in url: return 55
    if "semi-final-1" in url or "1st-semi" in url: return 53
    if "semi-final-2" in url or "2nd-semi" in url: return 54

    if soup:
        header_text = soup.get_text()
        m_text = re.search(r"(\d+)(?:st|nd|rd|th)\s+Match", header_text, re.IGNORECASE)
        if m_text: return int(m_text.group(1))
    return 0


def get_match_teams(soup):
    teams = []
    if not soup: return []
    for span in soup.find_all('span', class_='ds-text-tight-l'):
        t = normalize_team(span.get_text(strip=True))
        if t and t not in teams: teams.append(t)
    if len(teams) < 2 and soup.title and soup.title.string:
        title = soup.title.string
        if " vs " in title:
            parts = title.split(" vs ")
            teams = [normalize_team(p.split(",")[0].strip()) for p in parts]
    return teams[:2]


def parse_bowling_table(table, match_no, bowling_team, batting_team):
    data = []
    rows = table.find_all("tr")
    if not rows: return []

    for tr in rows:
        tds = tr.find_all("td")
        if len(tds) < 6: continue
        name = tds[0].get_text(strip=True).replace("†", "").replace("(c)", "").strip()
        if not name or any(x in name.lower() for x in ["extras", "total", "did not bat"]): continue
        try:
            data.append({
                "match_no": match_no,
                "bowler": name,
                "team": bowling_team,
                "against": batting_team,
                "overs": float(tds[1].get_text(strip=True)),
                "maidens": int(tds[2].get_text(strip=True)),
                "runs": int(tds[3].get_text(strip=True)),
                "wickets": int(tds[4].get_text(strip=True)),
                "economy": float(tds[5].get_text(strip=True)),
            })
        except:
            continue
    return data


async def main():
    if not os.path.exists(LINKS_FILE):
        print(f"❌ Error: {LINKS_FILE} not found.")
        return

    links_df = pd.read_csv(LINKS_FILE)
    all_bowling_data = []

    print(f"🚀 Starting Playwright Extraction for {len(links_df)} matches...")

    async with async_playwright() as p:
        # Launch a REAL browser (headless=False means you will see it pop up)
        # This is key to bypassing Cloudflare.
        browser = await p.chromium.launch(headless=False)
        context = await browser.new_context(
            user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36"
        )
        page = await context.new_page()

        for i, url in enumerate(links_df["match_url"]):
            try:
                if "full-scorecard" not in url:
                    scorecard_url = url.replace("live-cricket-score", "full-scorecard")
                else:
                    scorecard_url = url

                # Go to page and wait for load
                # We wait specifically for a table to appear
                await page.goto(scorecard_url, timeout=60000)
                try:
                    await page.wait_for_selector("table", timeout=10000)
                except:
                    print(f"⚠️ Timeout waiting for table on {scorecard_url}")

                # Get the HTML content
                content = await page.content()
                soup = BeautifulSoup(content, "html.parser")

                # --- DATA EXTRACTION ---
                match_no = get_real_match_no(scorecard_url, soup)
                teams = get_match_teams(soup)

                if len(teams) < 2:
                    print(f"⚠️ Skipped Match {match_no}: Could not identify teams.")
                    continue

                tables = []
                for tbl in soup.find_all("table"):
                    headers = [th.get_text(strip=True).upper() for th in tbl.find_all("th")]
                    if "O" in headers and "W" in headers and "ECON" in headers:
                        tables.append(tbl)

                extracted_count = 0
                for idx, table in enumerate(tables[:2]):
                    if idx == 0:
                        bowl_team, bat_team = teams[1], teams[0]
                    else:
                        bowl_team, bat_team = teams[0], teams[1]

                    rows = parse_bowling_table(table, match_no, bowl_team, bat_team)
                    all_bowling_data.extend(rows)
                    extracted_count += len(rows)

                print(f"✅ Match {match_no}: {teams[0]} vs {teams[1]} ({extracted_count} bowlers)")

                # Polite delay
                await asyncio.sleep(2)

            except Exception as e:
                print(f"❌ Error on {url}: {e}")
                traceback.print_exc()

        await browser.close()

    # Save
    if all_bowling_data:
        df = pd.DataFrame(all_bowling_data)
        df = df.sort_values(by=["match_no", "team", "bowler"])
        os.makedirs("data/processed", exist_ok=True)
        df.to_csv(OUTPUT_FILE, index=False)
        print(f"\n🎉 DONE! Saved {len(df)} rows to {OUTPUT_FILE}")


if __name__ == "__main__":
    asyncio.run(main())