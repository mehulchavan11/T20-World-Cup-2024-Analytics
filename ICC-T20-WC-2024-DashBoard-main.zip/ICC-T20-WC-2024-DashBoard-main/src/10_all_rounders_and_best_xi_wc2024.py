import pandas as pd
import numpy as np
from sklearn.preprocessing import MinMaxScaler

# =========================
# LOAD DATA
# =========================

bat = pd.read_csv("data/processed/wc_2024_batting.csv")
bowl = pd.read_csv("data/processed/wc_2024_bowlers_final.csv")
bowl = bowl.rename(columns={"bowler": "player"})


# =========================
# STEP 1: IDENTIFY WICKETKEEPERS (NO INPUT FILE NEEDED)
# =========================

bat["is_wk"] = (
    bat["player"].astype(str).str.contains("†", regex=False) |
    bat["out_status"].astype(str).str.contains("†", regex=False)
)

bat["player"] = (
    bat["player"]
    .str.replace("†", "", regex=False)
    .str.strip()
)

# =========================
# STEP 2: BATTING SCORE
# =========================
# Balanced for T20

bat["bat_score"] = (
    bat["runs"] * 1.0 +
    bat["strike_rate"] * 0.5 +
    (bat["fours"] * 1.0 + bat["sixes"] * 2.0)
)

bat_agg = (
    bat.groupby(["player", "team"], as_index=False)
       .agg(
           matches=("match_no", "nunique"),
           runs=("runs", "sum"),
           strike_rate=("strike_rate", "mean"),
           bat_score=("bat_score", "sum"),
           is_wk=("is_wk", "max")
       )
)

# =========================
# STEP 3: BOWLING SCORE
# =========================

bowl["bowl_score"] = (
    bowl["wickets"] * 25 -
    bowl["economy"] * 10
)

bowl_agg = (
    bowl.groupby(["player", "team"], as_index=False)
        .agg(
            wickets=("wickets", "sum"),
            economy=("economy", "mean"),
            bowl_score=("bowl_score", "sum")
        )
)

# =========================
# STEP 4: MERGE
# =========================

df = bat_agg.merge(
    bowl_agg,
    on=["player", "team"],
    how="outer"
)

df.fillna(0, inplace=True)

# =========================
# STEP 5: NORMALIZE SCORES
# =========================

scaler = MinMaxScaler()

df["norm_bat"] = scaler.fit_transform(df[["bat_score"]])
df["norm_bowl"] = scaler.fit_transform(df[["bowl_score"]])

# =========================
# STEP 6: ALL-ROUNDER INDEX
# =========================

df["all_rounder_index"] = df["norm_bat"] * df["norm_bowl"]

# =========================
# STEP 7: ROLE CLASSIFICATION
# =========================

def classify_role(row):
    if row["is_wk"]:
        return "wicketkeeper"
    if row["norm_bat"] > 0.65 and row["norm_bowl"] < 0.25:
        return "batsman"
    if row["norm_bat"] > row["norm_bowl"] and row["all_rounder_index"] > 0:
        return "batting_allrounder"
    if row["norm_bowl"] > row["norm_bat"] and row["all_rounder_index"] > 0:
        return "bowling_allrounder"
    if row["norm_bowl"] > 0.65:
        return "bowler"
    return "utility"

df["role"] = df.apply(classify_role, axis=1)

# =========================
# STEP 8: BUILD BEST XI
# =========================

best_xi = []

# WK (best bat score)
best_xi.append(
    df[df["role"] == "wicketkeeper"]
    .sort_values("bat_score", ascending=False)
    .head(1)
)

# Top 3 batsmen
best_xi.append(
    df[df["role"] == "batsman"]
    .sort_values("bat_score", ascending=False)
    .head(3)
)

# 2 Batting all-rounders
best_xi.append(
    df[df["role"] == "batting_allrounder"]
    .sort_values("all_rounder_index", ascending=False)
    .head(2)
)

# 1 Core all-rounder (best AR index overall)
best_xi.append(
    df[df["all_rounder_index"] > 0]
    .sort_values("all_rounder_index", ascending=False)
    .head(1)
)

# 2 Bowlers
best_xi.append(
    df[df["role"] == "bowler"]
    .sort_values("bowl_score", ascending=False)
    .head(2)
)

# Combine
best_xi_df = pd.concat(best_xi).drop_duplicates("player").head(11)

# =========================
# SAVE OUTPUTS
# =========================

df.sort_values("all_rounder_index", ascending=False) \
  .to_csv("data/analytics/all_rounders_wc2024.csv", index=False)

best_xi_df.to_csv("data/analytics/best_xi_wc2024.csv", index=False)

print("✅ All-rounders & Best XI created successfully")
