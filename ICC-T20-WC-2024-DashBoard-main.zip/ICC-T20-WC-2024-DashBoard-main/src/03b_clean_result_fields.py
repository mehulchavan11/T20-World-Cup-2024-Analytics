import pandas as pd
import os
import re

INPUT_FILE = "data/processed/wc_2024_match_summary_clean.csv"
OUTPUT_FILE = "data/processed/wc_2024_match_summary_final.csv"


def parse_result(row):
    result = str(row["result"]).lower()
    team1, team2 = row["team1"], row["team2"]

    runs1, runs2 = row["runs1"], row["runs2"]
    wkts1, wkts2 = row["wickets1"], row["wickets2"]

    winner_team = None
    win_type = None
    win_margin = None

    if "won by" in result:
        # Determine winner team
        if team1.lower() in result:
            winner_team = team1
            runs_w, runs_l = runs1, runs2
            wkts_w = wkts1
        elif team2.lower() in result:
            winner_team = team2
            runs_w, runs_l = runs2, runs1
            wkts_w = wkts2
        else:
            return winner_team, win_type, win_margin

        if "runs" in result:
            win_type = "runs"
            win_margin = abs(runs_w - runs_l)
        elif "wickets" in result:
            win_type = "wickets"
            win_margin = 10 - wkts_w

    elif "no result" in result or "abandoned" in result:
        win_type = "NR"

    elif "tied" in result:
        win_type = "tie"

    return winner_team, win_type, win_margin


if __name__ == "__main__":
    print("Loading cleaned match summary...")
    df = pd.read_csv(INPUT_FILE)

    print("Parsing winner & margins...")

    df[["winner_team", "win_type", "win_margin"]] = df.apply(
        parse_result, axis=1, result_type="expand"
    )

    os.makedirs("data/processed", exist_ok=True)
    df.to_csv(OUTPUT_FILE, index=False)

    print("✅ Winner fields cleaned & structured")
    print(f"Saved to {OUTPUT_FILE}")