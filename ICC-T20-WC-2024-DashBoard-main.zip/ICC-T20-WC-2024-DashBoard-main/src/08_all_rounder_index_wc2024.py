import pandas as pd
from sklearn.preprocessing import MinMaxScaler
import numpy as np

# -------------------
# Load data
# -------------------
bat = pd.read_csv("data/processed/wc_2024_batting.csv")
bowl = pd.read_csv("data/processed/wc_2024_bowlers_final.csv")

# -------------------
# Aggregate batting
# -------------------
bat_agg = (
    bat.groupby(["player", "team"])
       .agg(
            matches=("match_no", "nunique"),
            runs=("runs", "sum"),
            balls=("balls", "sum"),
            strike_rate=("strike_rate", "mean")
        )
       .reset_index()
)

bat_agg["bat_score"] = bat_agg["runs"] * bat_agg["strike_rate"]

# -------------------
# Aggregate bowling
# -------------------
bowl_agg = (
    bowl.groupby(["bowler", "team"])
        .agg(
            matches=("match_no", "nunique"),
            wickets=("wickets", "sum"),
            economy=("economy", "mean")
        )
        .reset_index()
)

bowl_agg.rename(columns={"bowler": "player"}, inplace=True)
bowl_agg["bowl_score"] = bowl_agg["wickets"] / bowl_agg["economy"]

# -------------------
# Merge (true all-rounders only)
# -------------------
ar = pd.merge(
    bat_agg,
    bowl_agg,
    on=["player", "team"],
    how="inner"
)

# -------------------
# Normalize (fair comparison)
# -------------------
scaler = MinMaxScaler()
ar["norm_bat"] = scaler.fit_transform(ar[["bat_score"]])
ar["norm_bowl"] = scaler.fit_transform(ar[["bowl_score"]])

# -------------------
# Core all-rounder index (PRODUCT)
# -------------------
ar["all_rounder_index"] = ar["norm_bat"] * ar["norm_bowl"]

# -------------------
# All-rounder TYPE
# -------------------
conditions = [
    ar["norm_bat"] > ar["norm_bowl"] * 1.15,
    ar["norm_bowl"] > ar["norm_bat"] * 1.15
]

choices = [
    "Batting All-Rounder",
    "Bowling All-Rounder"
]

ar["ar_type"] = np.select(
    conditions,
    choices,
    default="Balanced All-Rounder"
)

# -------------------
# Ranking
# -------------------
ar = ar.sort_values("all_rounder_index", ascending=False)

# -------------------
# Save
# -------------------
ar.to_csv("data/analytics/all_rounders_wc2024.csv", index=False)

print("✅ All-rounders with role bias saved")
print(ar[["player", "team", "ar_type", "all_rounder_index"]].head(10))
