import pandas as pd
import numpy as np
from sklearn.preprocessing import MinMaxScaler
import os

# ==========================
# FILE PATHS
# ==========================
BAT_FILE   = "data/processed/wc_2024_batting.csv"
BOWL_FILE  = "data/processed/wc_2024_bowlers_final.csv"

OUT_AR     = "data/analytics/all_rounders_wc2024.csv"
OUT_XI     = "data/analytics/best_xi_wc2024.csv"

os.makedirs("data/analytics", exist_ok=True)

# ==========================
# LOAD DATA
# ==========================
bat = pd.read_csv(BAT_FILE)
bowl = pd.read_csv(BOWL_FILE)

# Standardize column names
bat = bat.rename(columns={"player": "player", "team": "team"})
bowl = bowl.rename(columns={"bowler": "player", "team": "team"})

# ==========================
# AGGREGATE STATS
# ==========================
bat_agg = (
    bat.groupby(["player", "team"], as_index=False)
       .agg(
           matches=("match_no", "nunique"),
           runs=("runs", "sum"),
           balls=("balls", "sum"),
           fours=("fours", "sum"),
           sixes=("sixes", "sum"),
           strike_rate=("strike_rate", "mean")
       )
)

bowl_agg = (
    bowl.groupby(["player", "team"], as_index=False)
        .agg(
            matches=("match_no", "nunique"),
            wickets=("wickets", "sum"),
            runs_conceded=("runs", "sum"),
            overs=("overs", "sum"),
            economy=("economy", "mean")
        )
)

# ==========================
# SCORE CALCULATIONS
# ==========================
scaler = MinMaxScaler()

# ---- Batting Score
if len(bat_agg) > 0:
    bat_agg["norm_runs"] = scaler.fit_transform(bat_agg[["runs"]])
    bat_agg["norm_sr"]   = scaler.fit_transform(bat_agg[["strike_rate"]])
    bat_agg["bat_score"] = 0.7 * bat_agg["norm_runs"] + 0.3 * bat_agg["norm_sr"]
else:
    bat_agg["bat_score"] = 0

# ---- Bowling Score
if len(bowl_agg) > 0:
    bowl_agg["norm_wkts"] = scaler.fit_transform(bowl_agg[["wickets"]])
    bowl_agg["norm_eco"]  = 1 - scaler.fit_transform(bowl_agg[["economy"]])
    bowl_agg["bowl_score"] = 0.7 * bowl_agg["norm_wkts"] + 0.3 * bowl_agg["norm_eco"]
else:
    bowl_agg["bowl_score"] = 0

# ==========================
# MERGE
# ==========================
df = pd.merge(
    bat_agg,
    bowl_agg,
    on=["player", "team"],
    how="outer"
).fillna(0)

# ==========================
# ALL-ROUNDER SCORE
# ==========================
df["ar_score"] = df["bat_score"] * df["bowl_score"]

# ==========================
# ROLE CLASSIFICATION
# ==========================
def classify_role(row):
    if row["bat_score"] > 0 and row["bowl_score"] > 0:
        if row["bat_score"] > row["bowl_score"]:
            return "Batting AR"
        elif row["bowl_score"] > row["bat_score"]:
            return "Bowling AR"
        else:
            return "All-Rounder"
    elif row["bat_score"] > 0:
        return "Batsman"
    else:
        return "Bowler"

df["role"] = df.apply(classify_role, axis=1)

# ==========================
# WICKET KEEPER HANDLING
# ==========================
KNOWN_WK = [
    "Rishabh Pant",
    "Jos Buttler",
    "Quinton de Kock",
    "Rahmanullah Gurbaz",
    "Nicholas Pooran"
]

df["is_wk"] = df["player"].isin(KNOWN_WK)

# ==========================
# SAVE ALL-ROUNDERS FILE
# ==========================
df.sort_values("ar_score", ascending=False).to_csv(OUT_AR, index=False)

# ==========================
# BUILD BEST XI
# ==========================
wk = (
    df[df["is_wk"]]
    .sort_values("bat_score", ascending=False)
    .head(1)
)

df_no_wk = df[~df["player"].isin(wk["player"])]

batters = df_no_wk[df_no_wk["role"] == "Batsman"].sort_values("bat_score", ascending=False).head(3)
bat_ar  = df_no_wk[df_no_wk["role"] == "Batting AR"].sort_values("bat_score", ascending=False).head(2)
all_ar  = df_no_wk[df_no_wk["role"] == "All-Rounder"].sort_values("ar_score", ascending=False).head(1)
bowl_ar = df_no_wk[df_no_wk["role"] == "Bowling AR"].sort_values("bowl_score", ascending=False).head(1)
bowlers = df_no_wk[df_no_wk["role"] == "Bowler"].sort_values("bowl_score", ascending=False).head(4)

best_xi = pd.concat([batters, wk, bat_ar, all_ar, bowl_ar, bowlers])

# ==========================
# FINAL ASSERTION
# ==========================
assert len(best_xi) == 11, f"❌ Best XI has {len(best_xi)} players, expected 11"

best_xi.to_csv(OUT_XI, index=False)

print("✅ All-Rounders file saved:", OUT_AR)
print("✅ Best XI file saved:", OUT_XI)
