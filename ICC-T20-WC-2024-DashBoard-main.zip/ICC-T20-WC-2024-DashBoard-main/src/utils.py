# utils.py

TEAM_NAME_MAP = {
    "South": "South Africa",
    "SA": "South Africa",
    "Southafrica": "South Africa",

    "West": "West Indies",
    "WI": "West Indies",

    "United": "United States of America",
    "USA": "United States of America",

    "Sri": "Sri Lanka",
    "New": "New Zealand"
}

def normalize_team(team_name):
    if not team_name:
        return team_name

    team_name = team_name.strip()

    return TEAM_NAME_MAP.get(team_name, team_name)